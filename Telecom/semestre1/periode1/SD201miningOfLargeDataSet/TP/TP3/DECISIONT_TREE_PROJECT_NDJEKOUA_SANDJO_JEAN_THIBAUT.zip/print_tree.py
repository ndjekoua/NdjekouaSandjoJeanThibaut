"""
************************DEFINE UTILITY FUNCTIONS TO RPINT THE TREE****************************************
"""

def get_feature_values(feature_name,attribute_dictionary,from_attribute_to_index):
    index = from_attribute_to_index[feature_name]
    return [i for i in range(attribute_dictionary[index]+1)]


#print parameters of a single node of the tree.
def print_node(node,attribute_dictionary,from_attribute_to_index):
    if node["node_type"] != "Leaf":
        print("node type",node["node_type"])
        print("Level", node["depth"])
        print("Feature", (node["attribute_name"],get_feature_values(node["attribute_name"],attribute_dictionary,from_attribute_to_index)))
        print("Feature value :",node["attribute_value"])
        print("node gini", node["gini"])
        #print('%s[X%d < %.3f]' % ((depth * ' ', (node['index'] + 1), node['value'])))
        #print_tree(node['left'], depth + 1)

    else:
        print("node type", node['node_type'])
        print("Level", node["depth"])
        print("class", node["class"])
        print("node gini", node["gini"])
    return

#performs a BFS of the tree and print all the nodes.
def Print(root,attribute_dictionary,from_attribute_to_index):
    queue = []
    if not root :
        print("root is null")
        return

    queue.append(root)

    while(len(queue) != 0):
        node = queue[0]
        queue.remove(queue[0])
        print_node(node,attribute_dictionary,from_attribute_to_index)
        if node["left"] != "null":
            queue.append(node["left"])
        if node["right"] != "null":
            queue.append(node["right"])
