import numpy as np
import csv

""" *****************************************READ THE INPUT FILE AND STORE DATA IN AS AN ARRAY IN THE VARIABLE input_data*********************
"""
def readFile(input_path):
    input_data = []
    attribute_list = []
    with open(input_path) as csvfile:
        readCSV = csv.reader(csvfile, delimiter=' ')
        # allows to skip the first row
        attribute_list = next(readCSV)
        attribute_list = attribute_list[0:len(attribute_list)-1]
        for row in readCSV:
            input_data.append(np.asarray(row))
        #print(input_data[:, 1])
        return np.array(input_data), attribute_list

"""
*******************UTILITIES TO COMPUTE GINI INDEX****************************
"""
#compute the gini for a single node
def gini_single_node (group , classes):
    gini = 0.0
    size = float(len(group))
    score=0.0
    if size == 0:
      return 0.0
    for class_val in classes:
        p = [row[-1] for row in group].count(class_val)/size
        score += p*p
    gini += (1.0-score)
    return gini

"""Calculate the Gini index for a split dataset
    groups: it's a variable that contains the 2 list(left, and right)
    classes: it's a list that contains the possible values for a class
    return the value of the gini index"""
def gini_index(groups, classes):
    # count all samples at split point
    n_instances = float(sum([len(group) for group in groups]))
    # sum weighted Gini index for each group
    gini = 0.0
    for group in groups:
        size = float(len(group))
        # avoid iterating over an empty list and then divide by 0
        if size == 0:
            continue
        score = 0.0
        # score the group based on the score for each class
        for class_val in classes:
            p = [row[-1] for row in group].count(class_val) / size
            score += p * p
        # weight the group score by its relative size
        gini += (1.0 - score) * (size / n_instances)
    return gini

"""
**********************UTILITY TO CREATE TERMINAL NODES**********************
"""
# Create a terminal node value based on the elements in group and with all the needed informations
def to_terminal(group,depth,class_values):

  leaf_node = dict()
  leaf_node["node_type"] = "Leaf"
  leaf_node["gini"]= gini_single_node(group,class_values)
  leaf_node["depth"] = depth
  #put all the classes in a vector
  outcomes = [row[-1] for row in group]
  class0 = outcomes.count(class_values[0])
  class1 = outcomes.count(class_values[1])
  if class0 >= class1 :
      leaf_node["class"] = class_values[0]
  else :
      leaf_node["class"] = class_values[1]
  leaf_node["left"] = "null"
  leaf_node["right"] = "null"
  leaf_node["pruned"] = True
  return leaf_node

"""
**************UTILITIES TO COMPUTE THE GAIN FOR A SPLIT AVER A CERTAIN ATTRIBUTE*********************
"""
#compute the entropy of a single node
def compute_entropy(group,classes):
    #check if it's a node with node elements
    size = float(len(group))

    if size == 0:
        return 0
   # print("size", size)
    score = 0.0
    for class_val in classes:
        #print(group)
        p = [row[-1] for row in group if row != []].count(class_val) / size
        #because 0*log0  = 0
        if p == 0:
            continue
        score -= p * np.log2(p)
    return score

#compute and return the gain obtained for a split aver a specific attribute
def compute_gain(groups,classes):
    # count all samples at split point
    n_instances = float(sum([len(group) for group in groups]))
    gain = 0.0
    entropy = 0.0
    complete_list =[]
    for group in groups:
        #avoid iterating over an empty list to not get exeption
        if len(group) ==0:
            continue
        score = compute_entropy(group,classes)
        entropy -= score*(len(group)/n_instances)
    left,right = groups
    gain = compute_entropy(np.append(left,right),classes) - entropy
    return gain

"""
**********************UTILITY FUNCTIONS TO COMPUTE THE GENERALIZATION ERROR*****************************
"""

#given an inut row,and the root of the tree, it visit the tree untill reaching a leaf node
def predict_class(node, row, from_attribute_to_index):

    #check for ending condition
    if node["node_type"] == "Leaf":
        return node["class"]

    attribute_index = from_attribute_to_index[node["attribute_name"]]
    if int(row[attribute_index]) < int(node["attribute_value"]):
        return predict_class(node["left"], row, from_attribute_to_index)
    else:
        return predict_class(node["right"], row, from_attribute_to_index)

#compute the total number of leaf nodes of a given Tree.
def compute_total_leaf_nodes(node, total_leaf):
    if node["node_type"] == "Leaf" :
        return total_leaf +1;
    else:
        total_leaf = compute_total_leaf_nodes(node["left"], total_leaf)
        total_leaf = compute_total_leaf_nodes(node["right"], total_leaf)
    return total_leaf

#return the maximum depth in a tree
def get_max_depth(node,depth):
    if node["node_type"] == "Leaf":
        return depth
    max_left = get_max_depth(node["left"],depth+1)
    max_right = get_max_depth(node["right"],depth+1)
    if max_left > max_right:
        return max_left
    else:
        return max_right

#get the number of nodes for a specific depht
def get_num_nodes_for_depht(node,depth,tot_nodes):
    if int(node["depth"]) == depth:
        return tot_nodes+1
    elif node["node_type"] == "Leaf":
        return tot_nodes
    else:
        tot_nodes=get_num_nodes_for_depht(node["left"],depth,tot_nodes)
        tot_nodes=get_num_nodes_for_depht(node["right"],depth,tot_nodes)
        return tot_nodes

#compute the generalisation error of the tree given the tree structure and a dataset
def compute_error(root,dataset,alpha,from_attribute_to_index):
    mispredicted =0
    generalisation_error = 0
    for row in dataset:
        object_class = predict_class(root, row,from_attribute_to_index)
        if int(row[-1]) != int(object_class):
            mispredicted+=1

    total_leaf_nodes = compute_total_leaf_nodes(root, 0)
    generalisation_error = mispredicted + alpha*total_leaf_nodes
    return generalisation_error
