#Exercise on Python and PageRank
from scipy.sparse import coo_matrix
import numpy as np
from numpy.linalg import norm
import re
import os
import sys

def myPageRank(G_file_name, epsilon, beta):

    M = buildMatrix(G_file_name)[1]
    N = buildMatrix(G_file_name)[0]
    A = beta * M + (1 - beta) / N
    Pi = np.array([1 / N for x in range(int(N))])
    while True:
        ancientPi = Pi
        Pi = A.dot(ancientPi)
        if norm((Pi - ancientPi), ord=1) < epsilon:
            break
    return Pi


def buildMatrix(G_file_name):
    # G is a list a lines of the kind i j denoting that there is an edge between node i and j (from j to i)
    with open(G_file_name, "r") as file:
        lines = file.readlines()
    file.close()
    i_list = np.array([])
    j_list = np.array([])
    for line in lines:
        i_list = np.append(i_list, int(line.split()[0]) - 1)
    for line in lines:
        j_list = np.append(j_list, int(line.split()[1]) - 1)

    N = int(max(np.append(i_list, j_list)) + 1)
    data = [0 for x in range(len(i_list))]
    for j in j_list:
        k = j_list.tolist().count(j)  # number of successors of the page j
        for index in [x for x, y in enumerate(j_list) if y == j]:
            data[index] = 1 / k
    M = coo_matrix((data, (i_list, j_list)), shape=(N,N)).toarray()
    return (N, M)



input_path = sys.argv[1]
print(myPageRank(input_path,epsilon=0.001,beta=1))
print(myPageRank(input_path, epsilon = 0.001, beta = 0.8))

#############END OF QUESTION 1##########

path = sys.argv[2]
dictionary = {}
i = 1
hyperlinks = []

new_file_name = "web_graph.txt"
new_file = open(new_file_name, "w+")

for file_name in os.listdir(path):
    dictionary[file_name] = i
    i += 1
    #print(file_name)
    with open(path + file_name, "r",encoding = 'utf-8') as file:
        file_text = file.read()
        hyperlinks = np.append(hyperlinks, re.findall('a href="([^\'" >]+)', file_text))
    file.close()

for file_name in os.listdir(path):
    for html in hyperlinks:
        new_file.write(str(dictionary[html]) + " " + str(dictionary[file_name]) + "\n")
new_file.close()
#run the PageRank algorithm on the web graph
#PageRankVector = myPageRank(new_file_name,0.000001,1)
#print(PageRankVector)