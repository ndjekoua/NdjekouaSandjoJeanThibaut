import utility as u

def compute_generalisation_error(input_data,root,alpha):
    error =  u.compute_error(root,input_data,alpha,root['from_attribute_to_index'])
    print("The generalization error of the NON pruned Tree is :",error)
    return error
