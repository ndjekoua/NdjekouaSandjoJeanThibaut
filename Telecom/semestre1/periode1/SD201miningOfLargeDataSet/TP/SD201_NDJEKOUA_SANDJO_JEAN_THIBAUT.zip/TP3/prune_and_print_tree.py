import utility as u
import numpy as np
"""
*************************UTILITY FUNCTION TO PRUNE THE TREE*******************************
"""

#receives a tree,a level and then returns a pruned tree where one node belonging to level has been pruned
def get_pruned_tree(node,level,stop,class_values):
    #check if at least one node of this level has already beeen visited
    if stop:
      return node,stop
    if node["depth"] == level and node["pruned"] == False:
      left,right = node["groups"]
      return u.to_terminal(np.append(left,right),level,class_values),True
    node["left"],stop = get_pruned_tree(node["left"],level,stop,class_values)
    node["right"],stop = get_pruned_tree(node["right"],level,stop,class_values)
    return node,stop

#prune the tree
def prune_tree(input_data,node,alpha,min_size,from_attribute_to_index,class_values):
    max_depth = u.get_max_depth(node,1)
    best_tree = node
    best_error = u.compute_error(best_tree,input_data,alpha,from_attribute_to_index)
    #iterate over each level
    for level in range(max_depth-1,1,-1):
      tot_nodes = u.get_num_nodes_for_depht(node,0,alpha)
      #for each node belonging to this level
      index_node =0
      while index_node < tot_nodes:
       pruned_tree,stop=get_pruned_tree(best_tree,level,False,class_values)
       pruned_error = u.compute_error(pruned_tree,input_data,alpha,from_attribute_to_index)
       if pruned_error < best_error :
           best_tree = pruned_tree
           best_error = pruned_error
       index_node+=1

    return best_tree,best_error

def prune_and_print_tee(root,alpha,min_size):
    # Prune the tree and return the generalization error of the pruned tree
    pruned, generalization_error = prune_tree(root['input_data'], root, alpha, min_size, root['from_attribute_to_index'],root['class_values'])
    print("the generalisation error of the pruned tree is :", generalization_error)
    u.Print(pruned, root['attribute_dictionary'], root['from_attribute_to_index'])