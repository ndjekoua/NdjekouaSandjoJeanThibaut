import numpy as np
import utility as u



#contains as key the index name, and as value the max value for that attribute
attribute_dictionary = {}
#contains as key the attribute's name and as value the index o f the attribute.
from_attribute_to_index ={}
#contains the list of attribute
attribute_list = []
#contains the list of classes
class_values = []
#contains an array of input data
input_data = []
alpha = 0.5
min_size = 2
input_path = "dataset"

# Split a dataset based on an attribute and an attribute value
""" index: it's the index of the variable we are currently splitting on
    value: value is the current value we're considering (in the case of ordinal it may vary from min to max) 
    dataset:it's a list of rows we wnat to split
    @:return 
    2 list representing the left and the right part."""

def test_split(index, value, dataset):
    left, right = list(), list()
    for row in dataset:
        if int(row[index]) < int(value):
            left.append(row)
        else:
            right.append(row)
    return left, right


# Select the best split point for a dataset
""" dataset: it's list of rows we want to split
    class_list : it's the containing the possible classes
    split:attributes: it's a dictionary containing for each attribute key, the list of possible values it may assume
    @:return a dictionary(which represent a node) with the following keys: 
    -index : the index of the attribute the split has been done on
    -value : the value of the chosen attribute
    -groups : a list with the left and right groups
    -node_type : the type of the node "root,intermediate,leaf"
    -gini : the value of the gini for this split
"""
def get_split(dataset,depth):

    b_index, b_value, b_score,b_gain, b_groups = 999, 999, 999,999, None
    #iterate over the list of available index at the moment
    global attribute_list,class_values
    for attribute_index in range(len(attribute_list)):
      #now i iterate over all the possible values for this index
      for attribute_value in range(attribute_dictionary[attribute_index]+1):
       groups = test_split(attribute_index,attribute_value, dataset)
       gini = u.gini_index(groups, class_values)
       gain = u.compute_gain(groups,class_values)
       if gain < b_gain:
        b_index, b_value, b_score,b_gain, b_groups = attribute_index,attribute_value, gini,gain, groups
    #print("global varibables",globals()['attribute_list'])

    attribute_name = attribute_list[b_index]
    del attribute_list[b_index]
    return {'attribute_name': attribute_name, 'attribute_value': b_value,"pruned": False, 'groups': b_groups, 'gini': b_score,"depth" :depth}

def get_class(group,class_values):
    class_values = globals()['class_values']
    outcomes = [row[-1] for row in group]
    class0 = outcomes.count(class_values[0])
    class1 = outcomes.count(class_values[1])
    if class0 >= class1:
        return class_values[0]
    else:
        return class_values[1]

# Create child splits for a node or make terminal
"""@:parameter
    -node : a node containing a list withe the left and the rigth part of the node.
    -min_size contains the minmum number of elements per node.
    -depth is the depth of actual depth of the tree.
    @:return
    nothing
"""
def split(node, min_size, depth):

    if depth != 1:
        node["node_type"] = "Intermediate"
    left, right = node['groups']
    #leaving this list will allow me to prune the tree more easily
    #del (node['groups'])
    # check for a no split which means all the records belongs to the same class since one part is empty
    if len(left) != 0 and len(right) == 0:
        node['node_type'] = 'Leaf'
        node['class'] = get_class(left,globals()['class_values'])
        node['left'] = 'null'
        node['right'] = 'null'
        #node['left'] = u.to_terminal(left,depth+1,globals()["class_values"])
        #node["right"] = "null"
        return
    if len(right) != 0 and len(left) == 0:
        node['node_type'] = 'Leaf'
        node['class'] = get_class(right, globals()['class_values'])
        node['left'] = 'null'
        node['right'] = 'null'
        #node["right"] = u.to_terminal(right,depth+1,globals()["class_values"])
        #node["left"] = "null"
        return

    # process left child
    if len(left) <= min_size or len(globals()["attribute_list"]) == 0:
        node['left'] = u.to_terminal(left,depth+1,globals()["class_values"])
        #compute the gini and fro this array and store it
    else:
        #print("left depth =", depth)
        node['left'] = get_split(left,depth+1)
        split(node['left'], min_size, depth + 1)

    # process right child
    if len(right) <= min_size or len(globals()["attribute_list"])==0 :
        node['right'] = u.to_terminal(right,depth+1,globals()["class_values"])
    else:
            #print("right depth =",depth)
            #print(len(globals()["attribute_list"]))
            node['right']= get_split(right,depth+1)
            split(node['right'], min_size, depth + 1)


# Build a decision tree
"""@:parameter
  -inpput_path : absolute path of the input file
  -min_size: minimum number of records per nodes
"""
def BuildDecisionTree(input_path, min_size):

    globals()["input_data"],globals()["attribute_list"] = u.readFile(input_path)
    globals()["class_values"] = list(set(row[-1] for row in input_data))

    #for each attribute, store in a dictionary the max value
    for index in range(len(attribute_list)):
     #get the max index for this attribute from the input data
     max_index = np.argmax(input_data[:,index])
     #the attribute's max value in the dictionary
     attribute_dictionary[index] = int(globals()["input_data"][max_index,index])
     #store the index of this attribute in the dictionary.
     from_attribute_to_index[attribute_list[index]] = index

    if len(globals()['input_data']) <= 1:
        root = u.to_terminal(globals()['input_data'],1,globals()['class_values'])
    else:
       root = get_split(globals()["input_data"],1)
       root['node_type'] = "root"
       root['from_attribute_to_index'] = from_attribute_to_index
       root['class_values'] = class_values
       root['input_data'] = input_data
       root['attribute_dictionary'] = attribute_dictionary
       split(root, min_size, 1)
       print("\n\n***************ORIGINAL TREE*****************")
       # print the tree in a BFS fashion
       u.Print(root, attribute_dictionary, from_attribute_to_index)
       return root


