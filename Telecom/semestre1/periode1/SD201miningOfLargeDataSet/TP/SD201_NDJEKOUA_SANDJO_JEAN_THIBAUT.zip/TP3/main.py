import prune_and_print_tree as pruneTree
import utility as u
import compute_generalisation_error as ge
import BuildDecisionTree as bdt


""" 
*****************************MAIN**************************
 """

#build the decision tree
root = bdt.BuildDecisionTree(bdt.input_path,1)
error = ge.compute_generalisation_error (bdt.input_data,root,bdt.alpha)

print("\n\n*********PRUNED TREE**************")

#Prune the tree and return the generalization error of the pruned tree
pruneTree.prune_and_print_tee(root,bdt.alpha,bdt.min_size)