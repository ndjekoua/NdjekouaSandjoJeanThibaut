package tpt.dk908a;

import java.io.IOException;
import java.util.regex.Pattern;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.regex.Pattern;
import java.util.regex.Matcher;


public class NameMovie {

    public static class MapRatings extends Mapper<LongWritable, Text, Text, Text> {
    	public void map(LongWritable offset, Text moviePair, Context context)
    	    throws IOException, InterruptedException {
    	    String[] pair = moviePair.toString().split("\t");
          if(pair.length == 2){
            context.write(new Text(pair[0]), new Text(";"+pair[1]));
          }else{
            context.write(new Text(pair[2]), new Text(":"+pair[1]));
          }
    	}
    }

    private static final Pattern p = Pattern.compile("^([0-9]+),([^,\"]+|\"[^\"]+\"),(.+)$");

    public static class MapMovies extends Mapper<LongWritable, Text, Text, Text> {
    	public void map(LongWritable offset, Text movie, Context context)
    	    throws IOException, InterruptedException {
            if(offset.get() != 0){
              Matcher m = p.matcher(movie.toString());
              if (m.find()) {
                String movieId = m.group(1);
                String movieName = m.group(2);
                context.write(new Text(movieId), new Text(movieName));
              }
            }
    	}
    }

    public static class Reduce extends Reducer<Text, Text, Text, Text> {
	@Override
	public void reduce(Text movie, Iterable<Text> values, Context context)
	    throws IOException, InterruptedException {
        ArrayList<String> ids = new ArrayList<String>();
        String name = "No Occurence Found";

        boolean secondRun = false;

        for(Text v : values){
          String vString = v.toString();
          //Check where the value came from and which run it is
          if(vString.charAt(0) == ';'){
            ids.add(vString.substring(1,vString.length()));
          }else if(vString.charAt(0) == ':'){
            ids.add(vString.substring(1,vString.length()));
            secondRun = true;
          }else{
            name = v.toString();
          }

        }

        for(String id : ids){
          //Switch back name and id
          if(!secondRun){
            context.write(movie, new Text(name+"\t"+id));
          }else{
            context.write(movie, new Text(id+"\t"+name));
          }

        }
	}
    }
}
