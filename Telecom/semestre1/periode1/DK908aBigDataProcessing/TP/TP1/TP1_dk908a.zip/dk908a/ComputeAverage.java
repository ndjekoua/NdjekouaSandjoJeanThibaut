package tpt.dk908a;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

import org.apache.log4j.Logger;



public class ComputeAverage {
	
       
   public static class Map extends Mapper<LongWritable, Text, Text, FloatWritable> {
    	
	  public void map(LongWritable offset, Text line, Context context)
	      throws IOException, InterruptedException {
	         
	        if(offset.get() != 0){
           String[] review = line.toString().split(",");
           Text movie = new Text(review[1]);
           FloatWritable rating = new FloatWritable(Float.valueOf(review[2]));
           context.write(movie, rating);
          }
                 
	     }
    }
    
    public static class Reduce extends Reducer<Text, FloatWritable, Text, FloatWritable> {

	   public void reduce(Text movie, Iterable<FloatWritable> values, Context context) 
	      throws IOException, InterruptedException {
	      
		float sum = 0;
		int size =0;
		
	        for(FloatWritable v : values) { 
	    	 
	         	sum+= v.get(); /* for the value */
	    	    size++;
	         }
	      context.write(movie,new FloatWritable(sum/size));
	}
    }
}


