++++#/bin/bash

#export HADOOP_CLASSPATH="$(yarn classpath)"
mkdir classes
javac -classpath $HADOOP_CLASSPATH -d classes dk908a/ExtractUserMovies.java dk908a/CountPairs.java dk908a/SelectPairs.java dk908a/NameMovie.java dk908a/MovieRecommendation.java dk908a/RunAverage.java  dk908a/ComputeAverage.java ;
jar -cvf code.jar -C classes/ . ;
rm -r classes ;

#hadoop jar code.jar tpt.dk908a.RunAverage /datasets/movie_small /tmp/$USER
#hadoop jar code.jar tpt.dk908a.MovieRecommendation /datasets/movie_small /tmp/$USER

