%%                 TP4 : chaine de markov 
                      % deadline 22/10
        %NDJEKOUA SANDJO 
        %JEAN THIBAUT
 
%% loading the correspondance matrix
eval('correspondance')

%accessing letter corresponding to a specific state
%lettre = corresp{24,2}
%print(lettre);

%load the transition matrix
load 'bigramenglish'

%% 2.a) SIGNIFICATION DE LA PRMIERE LIGNE ET DE LA PREMIERE COLLONNE DE LA MATRICE DE TRANSITION
%la premiere ligne de la matrice de transition correspond a la
%probabilite de passer de l'etat initial a tous les autres 26 etats
%respectivement. par contre la derniere colonne correspond a la probabilite
%de passer de tout  les autres etats a l'etata final.

 
%% Afficher sur un graphique la fonction de repartition pour la ligne 1
%specique de la matrice de transition : dans ce cas ligne 1
% ROLE: elle a pour role d'associer a chaque etat une probabilite cumule
cs = cumsum(matrice_trans(1,:));
stem(cs)


%% 2.b) GENRER UN MOT:
 seq = generate_sate_seq(matrice_trans);
 word1 = display_seq(seq,corresp)
 seq = generate_sate_seq(matrice_trans);
 word2 = display_seq(seq,corresp)

 
 %% 3) GENERER UNE PHRASE
sentence1 = generate_sentence(matrice_trans,corresp)
sentence2 = generate_sentence(matrice_trans,corresp)

%% 4)Reconnaissance de language

[trans_mat_en ,dict] = modofie_mat_dict(matrice_trans,corresp);
load 'bigramfrancais'
[trans_mat_fr ,dict] = modofie_mat_dict(matrice_trans,corresp);

%% 4.a) vraissemblance pour la phrase 'to be or not to be'
[pro_en, pro_log_en] = calc_vraissemblance('to be or not to be',trans_mat_en,dict);
[pro_fr, pro_log_fr] = calc_vraissemblance('to be or not to be',trans_mat_fr,dict);
pro_en
pro_fr
 
%% 4.b° vraissemblance pour la phrase 'to be or not to be'
[pro_en, pro_log_en] = calc_vraissemblance('etre ou ne pas etre',trans_mat_en,dict);
[pro_fr, pro_log_fr] = calc_vraissemblance('etre ou ne pas etre',trans_mat_fr,dict);
pro_en
pro_fr





