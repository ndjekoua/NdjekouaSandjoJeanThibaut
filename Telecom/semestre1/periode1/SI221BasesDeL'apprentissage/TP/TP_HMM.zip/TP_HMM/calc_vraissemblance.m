function [ like_hood, likehood_log ] = calc_vraissemblance( phrase , trans_mat , dict )
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here









phrase = lower(strtrim(phrase));
phrase = ['-' phrase];
phrase = strrep(phrase,' ','+-');
%phrase = strrep(phrase,'.','+.');

seq_size = length(phrase);
state_seq = zeros(seq_size);

for i = 1:seq_size
    if(phrase(i) == '-')
       
        state =1;
    elseif (phrase(i)=='+')
        state = 28;
    else 
        
        state = abs(phrase(i)) - 95;
    end
    state_seq(i) = state ;
end  

like_hood = 1;
likehood_log = 0;
for i =2 : seq_size
    like_hood = like_hood*trans_mat(state_seq(i-1),state_seq(i));
    likehood_log = likehood_log + log(trans_mat(state_seq(i-1),state_seq(i)));
end

