function [ letter_seq ] = display_seq( input_seq, corresp )
%this function will transform an input sequence of numbers to an output
%seauence of letters thus, generating a word
%   input_seq : the sequence of input state numbers
%   letter_seq / seauence containig the letters in putput
end_state = 28;
letter_seq = [];


for i =1 : size(input_seq,2)
    state = input_seq(i);
   % if(state==1 && input_seq(i-1) == end_state)
     %   letter_seq = [letter_seq'']
   % elseif(state == end_state) 
   if(state == end_state) 
        continue
   else
        
        letter_seq = [letter_seq corresp{input_seq(i),2}];
    end   

end

letter_seq = char(letter_seq);

