function [ trans_mat_post , corresp_post ] = modofie_mat_dict( trans_mat, corresp)
%modife ls matrices de transition et de correspondance en ajout un etat
%correspondant au .
%   Detailed explanation goes here

 corresp_post = corresp;
 corresp_post{29,2} = '.';
 corresp_post{29,2} = 29;
 
 trans_mat_post = trans_mat;
 trans_mat_post(:,29)=0;
 trans_mat_post(29,:)=0;
 trans_mat_post(28,28)=0.0;
 trans_mat_post(28,1)=0.9;
 trans_mat_post(28,29)=0.1;
 trans_mat_post(29,29)=1; 
end

