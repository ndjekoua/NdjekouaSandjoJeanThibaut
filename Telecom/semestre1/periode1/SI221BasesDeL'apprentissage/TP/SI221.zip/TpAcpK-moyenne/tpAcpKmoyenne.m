
%% INITIAL IMAGES FROM LANDSTATTARASCOM CHANNEL
im1 = ima2mat('landsattarasconC1');
im2 = ima2mat('landsattarasconC2');
im3 = ima2mat('landsattarasconC3');
im4 = ima2mat('landsattarasconC4');
im5 = ima2mat('landsattarasconC5');
im6 = ima2mat('landsattarasconC6');
im7 = ima2mat('landsattarasconC7');
im8 = ima2mat('landsattarasconC8');
 
 
 figure();
 colormap(gray(200));
 image(im1),title('initial Landstat image 1');
 
 colormap(gray(200));
 figure,image(im2),title('initial Landstat image 2');
 
 colormap(gray(200));
 figure,image(im3),title('initial Landstat image 3');
  
 colormap(gray(200))
figure,image(im4),title('initial Landstat image 4');
 
 
 colormap(gray(200));
 figure,image(im5),title('initial Landstat image 5');
 
 colormap(gray(200));
figure,image(im6),title('initial Landstat image 6');
 
 
 colormap(gray(200));
 figure,image(im7),title('initial Landstat image 7');
 
 
 colormap(gray(200));
figure,image(im8),title('initial Landstat image 8');

 colormap(gray(200));
%store the original size for each image
originalLine = size(im1,1);
originalColumn = size(im1,2);

M = [im1(:) im2(:) im3(:) im4(:) im5(:) im6(:) im7(:) im8(:)];

%% HISTOGRAMM OF A MATRIX
%for each pixel's value the number of pixel that have that value
hist(im1(:),0:1:255)


%% 1-NORMALIZE DATA in the matrix M

nlig = size(M,1);
ncol = size(M,2);

%returns and array containing the mean for each column
mkArray = mean(M,1);
size(mkArray);

%returns and arrya containing the standard deviation for each column :
%flag=1 means normalize by N
stdArray = std(M,1,1);
size(stdArray);

for j = 1:ncol %iterate over for each column
    for i = 1:nlig %then iterate over the lines
        M(i,j) = (M(i,j) -mkArray(j))/stdArray(j);
    end
end 

%% 2-COMPUTE THE COVARIANCE MATRIX

 mycovariance = cov(M);
 
 %% 3.a COMPUTE EIGAN VECTORS AND VALUES
 
 %returns in A a matrix where each column is an eigain vector of cov, and
 %the eigain values are on the diagonale of B
 [A,B] = eig(mycovariance);
 
 %5 verification ordre ds vecteurs propre selon les valeurs propres
 
  %I = ones(nlig,ncol);

  %il s'ait de demontrer que (M-lambdaI)*X = 0 pour chaque vecteur propre
  %associe a chaque valuer propre
  
  %5) COMPOSANTS PRINCIPALE DANS LA BASE DE VECTEURS PROPRE
 
  Mp = M*A;
  
  %% 3.b pourcentage d'inertie pour chaque autovaleur
  B = B/sum(B(:));
  diag(B)*100
  
  
  
  %% 3.c APPLICATION
 
  for k = 1:8
  I = 255*(Mp( :,k) - min(Mp( :,k)))/(max(Mp(:,k)) -min(Mp(:,k)));
  %size(I)
  %%component1
  im= reshape(I,originalLine,originalColumn);
  figure()
  colormap(gray(200))%allows to color the image with gray color
  image(im),title(sprintf('final Landstat image %d ',k))
  %colormap(gray(200))
  %colormap(gray(200))%allows to color the image with gray color
  end
  
  %% 4) K-MOYENNE
  
   %% CLASSIFICQTION FOR IMAGE 4
   [classe,epoch] = mykmeans('landsattarasconC4',[12;85]);
   
   
   %% CLASSIFICATION FOR IMAGE 1
   [classe,epoch] = mykmeans('landsattarasconC1',[52;85]);
   
   
 %% 5 BONUS
 im1 = ima2mat('cam1');
 im2 = ima2mat('cam2');
 im3 = ima2mat('cam3');
 
 figure();
 colormap(gray(200));
 image(im1),title('initial image cam1');
 
 figure();
 colormap(gray(200));
 image(im2),title('initial image cam2');
  
 figure();
 colormap(gray(200));
 image(im3),title('initial image cam3');
  
 M = [im1(:) im2(:) im3(:)];
 vecteurInertie =ACP(M,3,originalLine,originalColumn)
 %from the previous result, we can conclude that the lasr 2 images from
 %channel contains more then 90% of the information
 
 %5.2 landstat images : already done previously
