%-input 
  % imagePath = path of the image proto = prototype vector
%output
%- classe = class for each pixel; epoch = number of epoch to classify the
%pixels
function [classe,epoch] = mykmeans(imagePath,proto)

im = ima2mat(imagePath);
%image(im4)
%colormap(gray(600))
im = im(:);

%proto = [52;85];
previousProto = [10;24];

%-1 because iwill incrment directly in the loop
epoch = 0;
while ~isequal(proto,previousProto)
   % fprintf('\n epoch: %d',epoch)
    %assign a class to each pixel of the image
    previousProto = proto;
    classe = kmeans2(im,proto);
    
    card1 = classe==1;
    card2 = classe==2;

    sumClass1=0;
    sumClass2=0;
    
    dim = size(im,1);
    %update the centroids
    for i= 1:dim %iterate over for each class
        %disp('epoch: %d',epoch)
        
         if classe(i) == 1
           sumClass1 = sumClass1 + im(i);
         else
            sumClass2 = sumClass2 + im(i);
         end
    end    
    epoch = epoch+1;
    proto = [sumClass1/(sum(card1));sumClass2/(sum(card2))];
end
   figure()
   colormap(flag)
   image(reshape(classe,512,512)),title(sprintf('classification of image %s',imagePath))

