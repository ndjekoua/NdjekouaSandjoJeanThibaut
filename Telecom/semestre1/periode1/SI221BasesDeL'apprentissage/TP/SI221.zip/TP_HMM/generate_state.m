function [ next_state ] = generate_state(current_state, trans_matrix )
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

%repositionne le genrateur de nombre
value = rand();








%compute the repartition function of a given a given state
cs = cumsum(trans_matrix(current_state,:));
next_state = 1;
while(value >= cs(next_state))
    next_state = next_state +1;
end

