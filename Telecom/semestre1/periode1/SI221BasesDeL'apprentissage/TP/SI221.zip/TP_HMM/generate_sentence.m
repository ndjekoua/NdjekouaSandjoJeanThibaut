function [sentence] = generate_sentence( trans_matrix , corresp )
%receives the transition matrix and return some sentences
%   Detailed explanation goes here










sentence = [];
n_iterations = 10;
for i = 1:n_iterations
    seq = generate_sate_seq(trans_matrix);
    word = display_seq(seq,corresp);
    sentence = [sentence word];
end

