im4 = ima2mat('landsattarasconC1');
image(im4)
colormap(gray(600))
im4 = im4(:);

proto = [52;85];
previousProto = [1;0];

%-1 because iwill incrment directly in the loop
epoch = 0;
while ~isequal(proto,previousProto)
    fprintf('\n epoch: %d',epoch)
    %assign a class to each pixel of the image
    previousProto = proto;
    classe = kmeans2(im4,proto);
    
    card1 = classe==1;
    card2 = classe==2;

    sumClass1=0;
    sumClass2=0;
    
    dim = size(im4,1);
    %update the centroids
    for i= 1:dim %iterate over for each class
        %disp('epoch: %d',epoch)
        
         if classe(i) == 1
           sumClass1 = sumClass1 + im4(i);
         else
            sumClass2 = sumClass2 + im4(i);
         end
    end    
    epoch = epoch+1;
    proto = [sumClass1/(sum(card1));sumClass2/(sum(card2))];
end
%figure()
%colormap(flag)
%image(reshape(classe,512,512))