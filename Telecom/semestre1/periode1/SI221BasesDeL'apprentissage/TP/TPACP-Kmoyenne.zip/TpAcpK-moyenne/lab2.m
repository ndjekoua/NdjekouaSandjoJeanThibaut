

im1= ima2mat('landsattarasconC4');
%nlig = size(im1,1);
%ncol=size(im1,2);
%image(im1)
%colormap(prism)
%hist(im1(:))
%mi= min(im1(:));
%ma= max(im1(:));
 
v= im1(:);%transform the matrix into a vector
proto = v>30 % proto contient la sorti desire
scatter(v,proto)% PLOT THE ELEMENTS WITH CLASS THEY HAVE BEEN ASSIGNED
size=length(proto);
w = [0.2,0.1];
i=1;
 while i < size
     y = [v(i) 1];
     a = w*y' ;
       if a > 0
          s = 1;
       else
           s=0;
       end   
    while s ~= proto[i]
          if a < 0 && s == 1
            w = w + 0.01*y;
          end
          if a > 1 && s == 0  
            w = w - 0.01*y;
          end
       a = w*y' ;
       if a > 30 
          s = 1;
       else
           s=0;
       end 
    end   
 end