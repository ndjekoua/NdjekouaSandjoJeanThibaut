function  vecteurInertie = ACP(inputMatrix,nChannels,originalLine,originalColumn)

%  1-NORMALIZE DATA in the matrix M

M = inputMatrix;
nlig = size(M,1);
ncol = size(M,2);


%returns and array containing the mean for each column
mkArray = mean(M,1);
size(mkArray);

%returns and arrya containing the standard deviation for each column :
%flag=1 means normalize by N
stdArray = std(M,1,1);
size(stdArray);

for j = 1:ncol %iterate over for each column
    for i = 1:nlig %then iterate over the lines
        M(i,j) = (M(i,j) -mkArray(j))/stdArray(j);
    end
end 

%2-COMPUTE THE COVARIANCE MATRIX

 mycovariance = cov(M);
 
 %3-compute eigan vectors and values
 
 %returns in A a matrix where each column is an eigain vector of cov, and
 %the eigain values are on the diagonale of B
 [A,B] = eig(mycovariance);

 size(A);
 
 %5 verification ordre ds vecteurs propre selon les valeurs propres
 
  %I = ones(nlig,ncol);

  %il s'ait de demontrer que (M-lambdaI)*X = 0 pour chaque vecteur propre
  %associe a chaque valuer propre
  
  %5) COMPOSANTS PRINCIPALE DANS LA BASE DE VECTEURS PROPRE
 
  Mp = M*A;
  
  %5b) pourcentage d'inertie pour chaque autovaleur
  B = B/sum(B(:));
  vecteurInertie=diag(B)*100;
  
  
  
  %3;3 APPLICATION
 
  for k = 1:nChannels
  I = 255*(Mp( :,k) - min(Mp( :,k)))/(max(Mp(:,k)) -min(Mp(:,k)));
  %size(I)
  %%component1
  im= reshape(I,originalLine,originalColumn);
  figure()
  colormap(gray(200))%allows to color the image with gray color
  image(im),title(sprintf('final image %d ',k))
  %colormap(gray(200))
  %colormap(gray(200))%allows to color the image with gray color
  end