function centeredMatrix = centerData(M)

M = ima2mat('landsattarasconC2');

nlig = size(M,1);
ncol = size(M,2);
%returns and array containing the mean for each column
mkArray = mean(M,1);

%returns and arrya containing the standard deviation for each column :
%flag=1 means normalize by N
stdArray = std(M,1,1);


for j = 1:ncol %iterate over for each column
    for i = 1:nlig %then iterate over the lines
        M(i,j) = (M(i,j) -mkArray(j))/stdArray(j);
    end
end 
centeredMatrix = M
