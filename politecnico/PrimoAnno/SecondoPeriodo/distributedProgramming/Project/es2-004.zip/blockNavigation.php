<!DOCTYPE html>
<html>
	<head>
		<title>Airpleane Seat Reservation</title>		
	</head>
	<body>
	<h2>Navigation is forbidden</h2>
	<p>Enables cookies to continue the navigation</p>
	</body>
</html>