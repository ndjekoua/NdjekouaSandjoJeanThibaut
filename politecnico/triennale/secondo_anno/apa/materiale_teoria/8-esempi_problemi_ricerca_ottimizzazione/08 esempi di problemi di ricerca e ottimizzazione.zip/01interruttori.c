#include<stdlib.h>
#include<string.h>
#include<stdio.h>

int **leggiFile(FILE *in, int *n, int *m) {
  int i, j, **mat;
  fscanf(in, "%d %d", n, m);
  mat = calloc(*n, sizeof(int *));

  for (i=0; i<*n; i++) {
    mat[i] = calloc(*m, sizeof(int));
    for (j=0; j<*m; j++) {
      fscanf(in, "%d", &mat[i][j]);
    }
  }
  return mat;
}
/*
int verifica(int **mat_int, int n, int m, int k, int *sol) {
  int i, j, ok = 1, *lampadine;
  // Alloca un vettore di lampadine inizializzato a zero (spente)
  lampadine = calloc(m, sizeof(int));
  // Per tutti gli interruttori del sottoinsieme
  for (i=0; i<k; i++) {
    // Per ogni lampadina
    for(j=0; j<m; j++) {
      // Esegui XOR tra lo stato della lampadina (j) e la cella relativa a questa lampadina rispetto all'interruttore corrente (sol[i])
      // LUCE XOR INT -> RISULTATO
      //    0 XOR 0   -> 0 lampadina � spenta e l'interruttore non tocca questa lampadina, lampadina rimane spenta
      //    0 XOR 1   -> 1 lampadina � spenta e l'interruttore tocca questa lampadina, lampadina si accende
      //    1 XOR 0   -> 1 lampadina � accesa e l'interruttore non tocca questa lampadina, lampadina rimane accesa
      //    1 XOR 1   -> 0 lampadina � accesa e l'interruttore tocca questa lampadina, lampadina si spegne
      lampadine[j] ^= mat_int[sol[i]][j];
    }
  }
  // Se anche una sola � spenta, l'AND tra il flag ok (inizialmente 1) e la lampadina spenta (a 0) risulta in 0
  for(i=0; i<m; i++)
    ok &= lampadine[i];

  free(lampadine);
  return ok;
}

*/

int verifica(int **mat_int, int n, int m, int k, int *sol) {
  int i, j, ok = 1, *lampadine;
  lampadine = calloc(m, sizeof(int));
  // Per tutti gli interruttori del sottoinsieme
  for (i=0; i<k; i++)
    for(j=0; j<m; j++)
      lampadine[j] += mat_int[sol[i]][j];

  for(i=0; i<m; i++) {
    lampadine[i] = lampadine[i]%2;
    ok &= lampadine[i];
  }

  free(lampadine);
  return ok;
}

int powerset_comb(int pos, int *sol, int n, int k, int start, int **mat_int,  int m) {

  int i;
  if (pos >= k) {
    if (verifica(mat_int, n, m, k, sol)) {
      printf("Insieme minimo di interruttori per accendere  tutte le lampadine:\n");
      for (i=0; i < k; i++)
        printf("%d ", sol[i]);
      printf("\n");
      return 1;
    }
    else
      return 0;
  }

  for (i = start; i < n; i++) {
    sol[pos] = i;
    if (powerset_comb(pos+1, sol, n, k, i+1, mat_int, m))
      return 1;
  }
  return 0;
}

int main(void) {
  int n, m, k, i, trovato=0;
  FILE *in = fopen("switches.txt", "r");

  int **inter = leggiFile(in, &n, &m);

  int *sol = calloc(n, sizeof(int));
  int *mark = calloc(n, sizeof(int));

  // Genera tutte le combinazioni di 'i' interruttori
  printf("Powerset mediante combinazioni semplici\n\n");

  for (k=1; k <= n && trovato==0; k++) {
    if(powerset_comb(0, sol, n, k, 0, inter, m))
      trovato = 1;
  }
  free(sol);
  free(mark);
  for (i=0; i < n; i++)
    free(inter[i]);
  free(inter);
  return 0;
}
