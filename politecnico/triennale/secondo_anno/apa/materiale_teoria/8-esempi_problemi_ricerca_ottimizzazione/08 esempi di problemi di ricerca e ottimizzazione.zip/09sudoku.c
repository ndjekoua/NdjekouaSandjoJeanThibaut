#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAXBUFFER 128

int num_sol=0;

/********************************************************************
  Prototipi
********************************************************************/

int **acquisisci(char* nomefile, int *dim_ptr);
int controlla(int **schema, int dim, int passo);
void disp_ripet(int **schema, int dim, int passo);

/********************************************************************
  Programma principale
********************************************************************/
int main() {
  int **schema, dim, i, j, risultato;
  char nomefile[20];

  printf("Inserire il nome del file: ");
  scanf("%s", nomefile);

  schema = acquisisci(nomefile, &dim);

  disp_ripet(schema, dim, 0);

  printf("\n Numero di soluzioni = %d\n", num_sol);

  for (i=0; i<dim; i++)
    free(schema[i]);

  free(schema);
  return risultato;
}

/********************************************************************
  Funzione ricorsiva di ricerca di una soluzione
********************************************************************/
void disp_ripet(int **schema, int dim, int passo) {
  int i, j, k;

  /* verifica di terminazione */
  if (passo >= dim*dim) {
    num_sol++;
    printf("Soluzione:\n");
    for (i=0; i<dim; i++) {
      for (j=0; j<dim; j++)
	    printf("%3d ", schema[i][j]);
      printf("\n");
    }
    return;
   }

  /* indici casella corrente */
  i = passo / dim;
  j = passo % dim;
  if (schema[i][j] != 0) {
    /* casella inizialmente piena: nessun tentativo da fare */
    disp_ripet(schema, dim, passo+1);
    return;
  }

  /* provo tutti i possibili valori da 1 a dim */
  for (k=1; k<=dim; k++) {
    schema[i][j] = k;
    if (controlla(schema, dim, passo))
      disp_ripet(schema, dim, passo+1);
    schema[i][j] = 0;
  }
  return;
}

/********************************************************************
  Funzione di controllo della validita' di una soluzione parziale
********************************************************************/
int controlla(int **schema, int dim, int passo) {
  int r,c, rb, cb, i, j, n=floor(sqrt(dim)), occ[dim];

  // indici della casella corrente
  r = passo / dim;
  c = passo % dim;

  // controllo la riga

  for(r=0; r<dim; r++) {

    for(c=0; c<dim; c++) //azzero vettore occorrenze
      occ[c] = 0;

    for(c=0; c<dim; c++)  //calcolo occorrenze
      occ[schema[r][c]-1]++;

    for(c=0; c<dim; c++) //verifico se c'e' piu' di un'occorrenza
      if(occ[c] > 1)
        return 0;
  }

  // controllo la colonna

  for(c=0; c<dim; c++) {

    for(r=0; r<dim; r++) //azzero vettore occorrenze
      occ[r] = 0;

    for(r=0; r<dim; r++)  //calcolo occorrenze
      occ[schema[r][c]-1]++;

    for(r=0; r<dim; r++) //verifico se c'e' piu' di un'occorrenza
      if(occ[r] > 1)
        return 0;
  }

  // controllo i blocchi

  for(r=0; r<dim; r=r+n) {
    rb = (r/n) * n;     // indice di riga  iniziale del blocco da controllare
    for(c=0; c<dim; c=c+n) {
      cb = (c/n) * n; // indice di colonna  iniziale del blocco da controllare
      for(r=0; r<dim; r++) //azzero vettore occorrenze
        occ[r] = 0;
      for(i=rb; i<rb+n; i++) //calcolo occorrenze
        for(j=cb; j<cb+n; j++)
          occ[schema[i][j]-1]++;
      for(r=0; r<dim; r++) //verifico se c'e' piu' di un'occorrenza
        if(occ[r] > 1)
          return 0;
    }
  }
  return 1;
}

/********************************************************************
  Funzione per la lettura dello schema di partenza
********************************************************************/
int **acquisisci(char* nomefile, int *dim_ptr) {
  int i, j, **schema, dimensione=0;
  char buf[MAXBUFFER];
  FILE *fp;

  fp = fopen(nomefile, "r");
  if (fp == NULL) {
    printf("Errore durante l'apertura del file\n");
    exit(1);
  }

  /* leggo la prima volta il file per sapere la dimensione dello schema */
  while (fgets(buf, MAXBUFFER, fp) != NULL) {
    dimensione++;
  }
  fclose(fp);

  /* allocazione memoria necessaria */
  schema = (int**)malloc((dimensione)*sizeof(int*));
  if (schema == NULL) {
    printf("Errore durante l'allocazione della memoria\n");
    exit(1);
  }

  for (i=0; i<dimensione; i++) {
    schema[i] = (int*)malloc(dimensione*sizeof(int));
    if (schema[i] == NULL) {
	  printf("Errore durante l'allocazione della memoria\n");
	  exit(1);
    }
  }

  /* leggo una seconda volta il file per memorizzare lo schema iniziale */
  fp = fopen(nomefile, "r");
  if (fp == NULL) {
    printf("Errore durante l'apertura del file\n");
    exit(1);
  }

  for (i=0; i<dimensione; i++) {
    for (j=0; j<dimensione; j++) {
	  fscanf(fp, "%d", &schema[i][j]);
    }
  }
  fclose(fp);

  *dim_ptr = dimensione;
  return schema;
}
