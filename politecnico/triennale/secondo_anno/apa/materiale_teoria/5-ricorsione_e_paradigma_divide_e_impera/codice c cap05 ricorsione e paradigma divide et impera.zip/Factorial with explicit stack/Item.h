

typedef struct { long n; } Item;

Item ITEMscan();
void ITEMshow(Item x);
