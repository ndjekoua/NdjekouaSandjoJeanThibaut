#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#define N 100

int factorial(int n);

int main(void)
{
	int n;
	printf("Input n:  ");
    scanf("%d", &n);
    printf("factorial of %d is: %d \n", n, factorial(n));
    return 0;
}

int factorial (int n)
{
	S stack;
	stack = STACKinit(N);
	STACKpush(stack, n);
	int fact = 1;
	while (STACKsize(stack) > 0)
    {
        int curr = STACKpop(stack);
        fact = fact * curr;
        if (curr != 1)
            STACKpush(stack, curr-1);
    }
    return fact;
}

