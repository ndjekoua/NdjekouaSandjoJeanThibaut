#include <stdio.h>

long fact(int n);

main() {
  int n;

  printf("Input n:  ");
  scanf("%d", &n);

  printf("factorial of n is: %d \n", fact(n));
}

long fact(int n) {
  long tot = 1;
  int i;

  for(i=2; i<=n; i++)
	tot = tot * i;

  return(tot);
}
