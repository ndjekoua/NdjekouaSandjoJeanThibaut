#include <stdio.h>
#include <stdlib.h>

#define V 8

int BinSearch(int v[], int l, int r, int k);

main() {
  int i, k, a[V];

  for (i=0; i<V; i++) {
    printf("Input a[%d]:", i);
    scanf("%d", &a[i]);
  }

  printf("Input key:  ");
  scanf("%d", &k);

  printf("-1 not found, else found at index: %d\n", BinSearch(a, 0, i-1, k));
}


int BinSearch(int v[], int l, int r, int k) {
  int m;

  if((r-l) == 0)
    if(v[l]==k)
      return(l);
	else
      return(-1);

  m = (l+r) / 2;

  if(v[m] >= k)
    return(BinSearch(v, l, m, k));
  else
    return(BinSearch(v, m+1, r, k));
}

