#include <stdio.h>

int fib(int n);

main() {
  int n;

  printf("Input n:  ");
  scanf("%d", &n);

  printf("fibonacci of %d is: %d \n", n, fib(n));
}

int fib(int n) {
  if(n == 0 || n == 1)
    return(n);

  return(fib(n-2) + fib(n-1));
}

