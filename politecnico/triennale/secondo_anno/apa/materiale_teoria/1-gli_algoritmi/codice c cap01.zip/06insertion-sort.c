#include <stdio.h>

#define MAX 10000

void InsertionSort(int A[], int l, int r);

main()
{
	int i, n, A[MAX];

	printf("Input array size (max 10000):  ");
    scanf("%d", &n);

    for (i = 0; i <n; i++)
	{
		  printf("Input value A[%d]:  ", i);
          scanf("%d", &A[i]);
    }

    InsertionSort(A, 0, n-1);

    printf("A sorted in ascending order is:\n");
    for (i = 0; i <n; i++)
          printf("A[%d] = %d\n", i, A[i]);

}
void InsertionSort(int A[], int l, int r)
{
	int i, j, x;
	for(i = l; i <= r; i++)
	{
		x = A[i];
		j = i - 1;
		while (j >= l && x < A[j])
		{
			A[j+1] = A[j];
			j--;
		}
		A[j+1] = x;
	}
}
