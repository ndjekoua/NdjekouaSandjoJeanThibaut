#include <stdio.h>
#define V 5

int LinearSearch(int v[], int l, int r, int k);
int LinearSearch2(int v[], int l, int r, int k);

main()
{
	int i, k, a[V];

    for (i=0; i<V; i++)
    {
        printf("Input a[%d]:", i);
        scanf("%d", &a[i]);
    }
    printf("Input key:  ");
    scanf("%d", &k);
    printf("-1 means not found, else found at index: %d\n", LinearSearch(a, 0, V-1, k));
}

int LinearSearch(int v[], int l, int r, int k)
{
     int i=l;
     int found=0;

     while (i<=r && found == 0)
        if (k == v[i])
            found =1;
        else
            i++;
     if (found ==0)
          return -1;
     else
        return i;
}

