#include <stdio.h>
#include <stdlib.h>

#define V 8

int BinSearch(int v[], int l, int r, int k);

main()
{
	int i, k, a[V];
    for (i=0; i<V; i++)
    {
        printf("Input a[%d]:", i);
        scanf("%d", &a[i]);
    }
    printf("Input key:  ");
    scanf("%d", &k);
    printf("-1 not found, else found at index: %d\n", BinSearch(a, 0, i-1, k));
}


int BinSearch(int v[], int l, int r, int k)
{
	int m, found;

	while(l<=r)
	{
		m =  l + (r-l)/2;
		if(v[m] == k)
            return(m);
        if(v[m] < k)
			 l = m+1;
		else r = m-1;
	}
	return(-1);
}
