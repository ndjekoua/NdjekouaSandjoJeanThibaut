#include <stdio.h>

int Prime(int n);

main()
{
	int n;
	printf("Input number:  ");
    scanf("%d", &n);
    if (Prime(n)== 0)
        printf("%d is not prime.\n", n);
    else
        printf("%d is prime.\n", n);
}
int Prime(int n)
{
	int fact;
   	if (n == 1) return 0;
	fact =2;
	while (n%fact != 0)
	{
		fact  = fact +1;
	}
    return (fact == n);
}
