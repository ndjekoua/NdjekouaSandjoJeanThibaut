void BubbleSort(Item A[], int l, int r);
void OptBubbleSort(Item A[], int l, int r);
void SelectionSort(Item A[], int l, int r);
void InsertionSort(Item A[], int l, int r);
void ShellSort(Item A[], int l, int r);
void CountingSort(Item A[], int l, int r, int k);
