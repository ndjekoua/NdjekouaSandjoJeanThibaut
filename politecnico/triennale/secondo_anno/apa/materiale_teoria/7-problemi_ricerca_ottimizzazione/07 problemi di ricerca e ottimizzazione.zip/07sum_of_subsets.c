#include<stdio.h>
#include <stdlib.h>

void Merge(int *A, int *B, int l, int q, int r);
void MergeSort(int *A, int *B, int l, int r);

int promising(int *val, int i,int partial_sum,int total, int X);
void sumset(int pos, int *val, int *mark,  int partial_sum, int total, int X);

void main(void) {
  int i, k, total=0;
  int *mark, *val, *tmp, X;

  printf("Enter number of elements:  ");
  scanf("%d",&k);

  val = malloc(k*sizeof(int));
  tmp = malloc(k*sizeof(int));
  mark = malloc(k*sizeof(int));

  for (i=0; i<k; i++)
    mark[i] = 0;

  printf("Input elements: \n");
  for (i=0; i<k; i++) {
    printf("val[%d] = ", i);
    scanf("%d", &val[i]);
    total+=val[i];
  }

  printf("Input sum: \n");
  scanf("%d", &X);

  MergeSort(val, tmp, 0, k-1);

  if((total < X))
    printf("No solution possible \n");
  else {
    printf("The solution is:\n");
    sumset(0, val, mark, 0, total, X);
  }
  return;
}

int promising(int *val, int pos, int partial_sum, int total, int X) {
  return(partial_sum+total>=X)&&(partial_sum+val[pos]<=X);
}


void sumset(int pos, int *val, int *mark, int partial_sum, int total, int X) {
  int j;

  if (partial_sum==X) {
    printf("\n{\t");
    for(j=0;j<pos;j++)
      if(mark[j])
        printf("%d\t",val[j]);
      printf("}\n");
    return;
  }

  if (promising(val,pos,partial_sum,total,X)) {
    mark[pos]=1;
    sumset(pos+1, val, mark, partial_sum+val[pos], total-val[pos], X);
    mark[pos]=0;
    sumset(pos+1, val, mark, partial_sum, total-val[pos], X);
  }
}


void Merge(int *A, int *B, int l, int q, int r) {
  int i, j, k;
  i = l;
  j = q+1;
  for(k = l; k <= r; k++)
    if (i > q)
      B[k] = A[j++];
    else if (j > r)
      B[k] = A[i++];
    else if ( (A[i] < A[j]) || (A[i] == A[j])  )
      B[k] = A[i++];
    else
      B[k] = A[j++];
  for ( k = l; k <= r; k++ )
    A[k] = B[k];
  free(B);
  return;
}

void MergeSort(int *A, int *B, int l, int r) {
  int q, i;
  if (r <= l)
    return;
  q = (l + r)/2;
  MergeSort(A, B, l, q);
  MergeSort(A, B, q+1, r);
  Merge(A, B, l, q, r);
}
